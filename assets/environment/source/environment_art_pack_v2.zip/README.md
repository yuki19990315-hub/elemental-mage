# Elemental Mage - Environment pack v2

Extracted from the new high-detail environment and obstacle concept illustrations.

- 5 themes × 4 floor tiles = 20 opaque 64×64 RGBA PNGs
- 5 themes × 4 wall/edge modules = 20 opaque 64×64 RGBA PNGs
- 12 visually reviewed obstacle variants = 12 transparent 128×128 RGBA PNGs
- 11 atlases and a JSON manifest with source, dimensions, pivot, blocking properties, file checksums.

WARNING: The concept-board crops are **not guaranteed seamless** and walls are decorative modules, not algorithmically autotileable. Obstacle transparency was estimated from the artwork (GrabCut) and needs QA before final release. The sprites and metadata are candidate art for the playable prototype, not finished AAA hand-authored assets.

Extract via `python tools/unpack_environment_art.py`. Assets can then be used with the relative paths in `assets/environment/v2/manifest.json`.
